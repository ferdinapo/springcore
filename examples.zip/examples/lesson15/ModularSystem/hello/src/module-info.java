/* Copyright © 2021 Oracle and/or its affiliates. All rights reserved. */

module hello {
    requires  people;
}
