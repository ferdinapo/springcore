/* Copyright © 2021 Oracle and/or its affiliates. All rights reserved. */

package com.name;

public class Names {
    public static String getName(){
        return "Duke!";
    }
}