/* Copyright © 2021 Oracle and/or its affiliates. All rights reserved. */

package com.question;

public class Questions {
    public static String getQuestion(){
        return "How are you?";
    }
}
