package lesson08;

public class ForLoop {
    
    public static void main(String args[]){
        
        for (int i = 0; i < 9;  i++ ){
            System.out.println("i: " + i);
        }

    }        
}
