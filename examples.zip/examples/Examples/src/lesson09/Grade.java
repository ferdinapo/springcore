package lesson09;

public enum Grade {
    F, D, C, B, A;
}
