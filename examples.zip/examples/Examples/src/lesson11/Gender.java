package lesson11;

/**
 * @author MikeW
 */
public enum Gender { MALE, FEMALE }
