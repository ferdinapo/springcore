package lesson11;

/**
 * @author MikeW
 */
public enum Role { STAFF, MANAGER, EXECUTIVE }
