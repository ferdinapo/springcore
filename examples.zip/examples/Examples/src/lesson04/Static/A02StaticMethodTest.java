package lesson04.Static;

public class A02StaticMethodTest {
  public static void main(String[] args) {
    StaticHelper.printMessage("hello");
  }
}
