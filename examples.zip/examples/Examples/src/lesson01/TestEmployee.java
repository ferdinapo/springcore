package lesson01;

/**
 * @author $ {USER}
 **/
public class TestEmployee {
    public static void main(String[] args) {
        Employee emp = new Employee();
        emp.changeName("Tom");
        emp.raiseSalary(1000.0);
        System.out.println("Employee name is "+ emp.name );
        System.out.println("Employee salary raise is "+ emp.salary);
    }
}
