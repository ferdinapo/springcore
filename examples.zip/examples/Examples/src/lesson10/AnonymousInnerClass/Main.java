package lesson10.AnonymousInnerClass;

public class Main {
  public static void main(String[] args) {
    Z07Analyzer.main(args);
  }
}
