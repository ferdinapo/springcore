package lesson10.AnonymousInnerClass;

public class AnalyzerTool {
  public boolean arrContains(String sourceStr, String searchStr){
    return sourceStr.contains(searchStr);
  }  
}
