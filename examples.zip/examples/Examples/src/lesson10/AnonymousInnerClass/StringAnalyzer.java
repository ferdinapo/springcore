package lesson10.AnonymousInnerClass;

public interface StringAnalyzer {
  public boolean analyze(String sourceStr, String searchStr);
}
