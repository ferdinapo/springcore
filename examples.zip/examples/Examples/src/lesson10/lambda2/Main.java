package lesson10.lambda2;

/**
 *
 * @author MikeW
 */
public class Main {

  public static void main(String[] args) {
    
    
  }
}
