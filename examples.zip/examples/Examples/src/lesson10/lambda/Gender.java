package lesson10.lambda;

/**
 * @author MikeW
 */
public enum Gender { MALE, FEMALE }
