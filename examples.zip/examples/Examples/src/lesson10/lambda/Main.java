package lesson10.lambda;

/**
 *
 * @author MikeW
 */
public class Main {

  public static void main(String[] args) {
    
    RoboCallTest01.main(args);
    RoboCallTest02.main(args);
    RoboCallTest03.main(args);
    RoboCallTest05.main(args);
    
  }
}
