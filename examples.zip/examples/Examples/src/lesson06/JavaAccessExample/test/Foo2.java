package lesson06.JavaAccessExample.test;

public class Foo2 {
    protected int result = 20;
}
