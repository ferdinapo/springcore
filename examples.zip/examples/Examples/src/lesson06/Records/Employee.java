package lesson06.Records;


import java.time.LocalDate;
import java.util.Objects;

//Equivalent declaration for and Employee immutable Object

record Employee(int id, String firstName, String lastName, double salary,  LocalDate hireDate) {

    public static void main(String[] args) {
        Employee employeeRecord = new Employee(1, "jacobo", "Marcos", 20000, LocalDate.of(2006, 5, 22));
        System.out.println(employeeRecord);

        EmployeeC employeeClass = new EmployeeC(1, "jacobo", "Marcos", 20000, LocalDate.of(2006, 5, 22));
        System.out.println(employeeClass);
    }
}

class EmployeeC{
    private final int id;
    private final String firstName;
    private final String lastName;
    private final double salary;
    private final LocalDate hireDate;

    public EmployeeC(int id, String firstName, String lastName, double salary,  LocalDate hireDate) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = salary;
        this.hireDate = hireDate;
    }

    public int id() {
        return id;
    }

    public String firstName() {
        return firstName;
    }

    public String lastName() {
        return lastName;
    }

    public double salary() {
        return salary;
    }

    public LocalDate hireDate() {
        return hireDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeC employeeC = (EmployeeC) o;
        return id == employeeC.id && Double.compare(employeeC.salary, salary) == 0
                && Objects.equals(firstName, employeeC.firstName)
                && Objects.equals(lastName, employeeC.lastName)
                && Objects.equals(hireDate, employeeC.hireDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, firstName, lastName, salary, hireDate);
    }

    @Override
    public String toString() {
        return "EmployeeC{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", salary=" + salary +
                ", hireDate=" + hireDate +
                '}';
    }
}