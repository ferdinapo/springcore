package lesson06.Final;

public final class FinalParentClass { }
