package lesson06.Final;

// compile time error
//public class ChildClass extends FinalParentClass { }
