/**
 * @author oracle
 **/
module labs.client {
    requires java.logging;
    requires jdk.localedata;
}
