/**
 * @author oracle
 **/
module labs.client {
    requires java.logging;
    requires labs.pm;
    requires io.helidon.webserver;
    uses labs.pm.service.ProductManager;
}

