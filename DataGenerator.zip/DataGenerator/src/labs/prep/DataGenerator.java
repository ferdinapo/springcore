/*
 * Copyright (C) 2019 oracle
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package labs.prep;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.MessageFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 *
 * @author oracle
 */
public class DataGenerator {

    private static ResourceBundle config = ResourceBundle.getBundle("labs.prep.config");
    private static Path productSourcePath = Path.of(config.getString("products.source.path"));
    private static Path reviewSourcePath = Path.of(config.getString("reviews.source.path"));
    private static Path dataPath = Path.of(config.getString("data.output.path"));
    private static MessageFormat productFormat = new MessageFormat(config.getString("product.format"));
    private static MessageFormat reviewFormat = new MessageFormat(config.getString("review.in.format"));
    private static Logger logger = Logger.getLogger(DataGenerator.class.getName());

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Files.list(dataPath).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ex) {
                    logger.log(Level.SEVERE, "Error deleting files", ex);
                }
            });
            List<String> products = Files.readAllLines(productSourcePath, Charset.forName("UTF-8"));
            List<String> reviews = Files.readAllLines(reviewSourcePath, Charset.forName("UTF-8"));
            products.forEach(s -> generateDataset(s, reviews));
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error generating files", ex);
        }
    }

    public static void generateDataset(String product, List<String> reviews) {
        try {
            // Parse Product text
            Object[] values = productFormat.parse(product);
            String type = (String) values[0];
            int id = Integer.parseInt((String) values[1]);
            String name = (String) values[2];
            BigDecimal price = BigDecimal.valueOf(Double.parseDouble((String) values[3]));
            int rating = Integer.parseInt((String) values[4]);
            int expiry = Integer.parseInt((String) values[5]);
            LocalDate bestBefore = (type.equals("D")) ? LocalDate.now() : LocalDate.now().plusDays(expiry);

            // Write product file, parse reviews and write reviews file
            try ( PrintWriter productFile = new PrintWriter(
                    new OutputStreamWriter(
                            Files.newOutputStream(dataPath.resolve(Path.of(MessageFormat.format(config.getString("product.output.file"), id))),
                                    StandardOpenOption.CREATE),
                            "UTF-8"))) {
                List<String> productReviews = reviews.stream().filter(r -> r.startsWith(String.valueOf(id))).collect(Collectors.toList());
                if (!productReviews.isEmpty()) {
                    try ( PrintWriter reviewsFile = new PrintWriter(
                            new OutputStreamWriter(
                                    Files.newOutputStream(dataPath.resolve(Path.of(MessageFormat.format(config.getString("review.output.file"), id))),
                                            StandardOpenOption.CREATE),
                                    "UTF-8"))) {
                        int sum = 0;
                        for (int i = 0; i < productReviews.size(); i++) {
                            String pr = productReviews.get(i);
                            Object[] reviewValues = reviewFormat.parse(pr);
                            sum += Integer.valueOf((String) reviewValues[1]).intValue();
                            String reviewOut = MessageFormat.format(config.getString("review.out.format"), reviewValues[1], reviewValues[2]);
                            if (i == productReviews.size() - 1) {
                                reviewsFile.append(reviewOut);
                            } else {
                                reviewsFile.append(reviewOut + System.lineSeparator());
                            }
                        }
                        rating = Math.round((float) sum / productReviews.size());
                    }
                } else {
                    rating = 0;
                }
                String txt = MessageFormat.format(config.getString("product.format"), type, Integer.valueOf(id), name, price, Integer.valueOf(rating), bestBefore);
                productFile.append(txt);
            }
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Error writing data", ex);
        } catch (ParseException ex) {
            logger.log(Level.SEVERE, "Error parsing data", ex);
        }
    }
}
