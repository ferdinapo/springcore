/**
 * @author oracle
 **/
module labs.client {
    requires java.logging;
    requires labs.pm;
    uses labs.pm.service.ProductManager;
}

