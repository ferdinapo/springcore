/**
 * @author oracle
 **/
module labs.pm {
    exports labs.pm.service;
    exports labs.pm.data;
}